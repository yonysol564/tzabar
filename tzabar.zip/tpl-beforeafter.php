<?php
/* Template Name: Before After */ 
	get_header(); 
	$terms = get_terms('care_cat', array('hide_empty'=>false));

	$face_posts_show = get_field('face_posts_show', 'option');
	$body_posts_show = get_field('body_posts_show', 'option');

	$post_show_before_after_body = get_field('post_show_before_after_body');
	$post_show_before_after_face = get_field('post_show_before_after_face');
?>
<?php while ( have_posts() ) : the_post(); ?>
<div class="wrapper">
	<div class="before_after_top">
		<div class="container">
		<?php 
			$url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
		?>
			<div class="before_cont beforeAfterManBG" style="background-image: url(<?php echo $url; ?>); ">
				<?php get_template_part('inc/breadcrumbs'); ?>
				<div class="btns beforeAfter_text">
					<div class="clear"></div>
					<h1 class="title"><?php the_title(); ?></h1>
					<div class="cont">
						<?php the_content(); ?>
						<div class="mob_img_show">
							<img src="<?php echo $url; ?>" title="" alt=""> 
						</div>
					</div>
				</div>
				<ul class="beforeAfter_tabs_ul">
					<?php  
						$cnt = 1;
						foreach ($terms as $term) 
						{
						?>
							<li class="beforeAfter_tabs_li">
								<button type="button" class="beforeAfter_tabs_btn <?php if($cnt == 1){ echo 'active'; } ?>"><?php echo $term->name; ?></button>
							</li>
						<?php 
						}
					?>
				</ul>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
		</div>
	</div>
	<div class="maincontent">
		<div class="container">
			<ul class="tabs">
				<?php
					if ($body_posts_show) {
						foreach ($body_posts_show as $item) {
					?>
					<li>
						<a href="<?php echo get_permalink($item->ID); ?>" class="list1"><?php echo get_the_title($item->ID); ?></a>
					</li>
					<?php
						}
					}
				?>
			</ul>
			<ul class="tabs">
				<?php
					if ($face_posts_show) {
						foreach ($face_posts_show as $item) {
					?>
					<li>
						<a href="<?php echo get_permalink($item->ID); ?>" class="list1"><?php echo get_the_title($item->ID); ?></a>
					</li>
					<?php
						}
					}
				?>
			</ul>

		</div>

		<?php get_template_part('inc/beforeafter' ,'tabs'); ?>
		
		<?php get_template_part('inc/consult' ,'doctor'); ?>

	</div>
	<div class="clear"></div>
	<div class="push"></div>
</div>

<?php endwhile; // End of the loop. ?>

<?php

get_sidebar();
get_footer();
