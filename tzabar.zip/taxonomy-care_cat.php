<?php get_header(); die('sdsd'); ?>
	<div>
		
	</div>
<?php 
	get_sidebar();
	get_footer(); 
?>