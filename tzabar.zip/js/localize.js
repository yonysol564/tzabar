jQuery(document).ready(function($) {
	console.log("asd");	
});