<div class="breadcrumbs_div">
	<div class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/">
	    <?php
		if ( function_exists('yoast_breadcrumb') ) {
		     yoast_breadcrumb('<p id="breadcrumbs">','</p>');
		}
		?>
	</div>
</div>