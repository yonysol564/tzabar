<?php get_header(); ?>



<?php
get_sidebar();
get_footer();
?>